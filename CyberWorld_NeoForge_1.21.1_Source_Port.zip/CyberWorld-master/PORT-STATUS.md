# CyberWorld → NeoForge 1.21.1 port status

## Port direction

This project is a **NeoForge mod** now, not a Paper plugin. The previous Bukkit/Paper lifecycle and generator entrypoints have been removed. A custom chunk-generator codec (`cyberworld:cyberworld`) is registered, and `data/cyberworld/worldgen/world_preset/cyberworld.json` defines a CyberWorld preset for the Overworld while preserving vanilla Nether/End generators. The preset is added to `data/minecraft/tags/worldgen/world_preset/normal.json` and localized in `assets/cyberworld/lang/en_us.json` so it can appear in the world-type selector.

## Ported areas

- Replaced the Paper `JavaPlugin` container with a NeoForge config/resource holder.
- Replaced Bukkit `ChunkData` with a per-chunk state buffer that the Minecraft `ChunkGenerator` copies into `ChunkAccess`.
- Added the native NeoForge `ChunkGenerator` codec and data-driven world preset.
- Replaced Bukkit `Material` with a small bridge over vanilla Minecraft blocks.
- Reworked the old numeric block/metadata mapping to emit Minecraft 1.21.1 `BlockState` values and properties.
- Replaced Bukkit's 2D `BiomeGrid` with a view sampled from the current `BiomeSource`.
- Kept the existing city maps, road/highway/sewer, building, factory, sign, terrain and schematic-selection algorithms in `CyberWorldObjectGenerator`.
- Kept all bundled original `.schematic` assets (including the `schematics.zip` collection; 587 schematic files were counted in the archive).

## Use

1. Build using JDK 21 and Gradle 8.10+ with network access: `gradle clean build`.
2. Copy `build/libs/cyberworld-neoforge-1.21.1-1.21.1-neoforge-port.jar` into a Minecraft 1.21.1 NeoForge `mods` folder.
3. Create a **new world** and choose the **CyberWorld** world preset if it is listed. If custom presets do not appear in the UI on your specific launcher, the preset JSON can be loaded via a datapack/world-preset selection workflow. Do not apply it to an existing world.
4. The first load extracts the bundled schematic assets to `config/cyberworld/schematics/`.

## Verification / limitations

- This is a **source port**, not a validated installable JAR. A full build or in-game run could not be completed in this environment because Gradle is not installed and network access to NeoForge/Maven repositories is unavailable. Resource JSON files were parsed successfully, and a subset of the pure-Java city/noise algorithms compiled independently; this does not substitute for a complete NeoForge build.
- NeoForge 1.21.1's chunk generator APIs have been implemented against the 1.21.1 mapped API shape, but must still be compiler-checked against NeoForge 21.1.x.
- The original algorithm assumes a 0–255 Y range. The custom buffer preserves that assumption and leaves the newer negative and upper world-height bands empty, as the old plugin did not generate them.
- Original Bukkit settings are baked into defaults in this port; the old Bukkit config file is not migrated yet.
- Vanilla biome decoration and carvers are disabled for this generator to avoid vanilla trees/ores carving through the generated city blocks. Mob-spawn behavior and heightmaps should be tested in a live world.
- A few legacy block metadata variants cannot represent every pre-1.13 state exactly in the modern block-state system; unmatched names fall back to stone rather than crashing.
