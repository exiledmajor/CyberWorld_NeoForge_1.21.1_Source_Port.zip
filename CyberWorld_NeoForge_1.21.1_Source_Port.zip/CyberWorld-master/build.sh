#!/usr/bin/env sh
set -eu
# Run from the project root with JDK 21 and Gradle 8.10+ installed.
exec gradle clean build
