package io.github.kuohsuanlo.cyberworld;

/** Compact, rotatable block arrays used by CyberWorld's original city layout algorithms. */
public class SimplifiedSchematic {
    private byte[] blocks_id;
    private short[] wide_ids;
    private byte[] blocks_data;
    private int width, height, length;

    public SimplifiedSchematic(Schematic.Data source) {
        if (source == null) throw new IllegalArgumentException("Schematic could not be loaded");
        width = source.width;
        height = source.height;
        length = source.length;
        blocks_id = source.ids;
        wide_ids = source.wideIds;
        blocks_data = source.data;
    }

    /** Make an independent backup without decoding the source NBT a second time. */
    public SimplifiedSchematic copy() {
        SimplifiedSchematic copy = new SimplifiedSchematic(this.width, this.height, this.length,
                blocks_id.clone(), wide_ids == null ? null : wide_ids.clone(), blocks_data.clone());
        return copy;
    }

    private SimplifiedSchematic(int width, int height, int length, byte[] ids, short[] wideIds, byte[] data) {
        this.width = width;
        this.height = height;
        this.length = length;
        this.blocks_id = ids;
        this.wide_ids = wideIds;
        this.blocks_data = data;
    }

    public void rotate(int angle) {
        angle %= 360;
        if (angle < 0) angle += 360;
        if (angle == 0 || angle % 90 != 0) return;

        int oldW = width, oldH = height, oldL = length;
        int newW = angle == 180 ? oldW : oldL;
        int newL = angle == 180 ? oldL : oldW;
        int volume = newW * oldH * newL;
        byte[] newIds = new byte[volume];
        short[] newWideIds = wide_ids == null ? null : new short[volume];
        byte[] newData = new byte[volume];

        for (int x = 0; x < oldW; x++) for (int z = 0; z < oldL; z++) for (int y = 0; y < oldH; y++) {
            int oldIndex = index(x, y, z, oldW, oldL);
            int nx, nz;
            switch (angle) {
                case 90: nx = oldL - 1 - z; nz = x; break;
                case 180: nx = oldW - 1 - x; nz = oldL - 1 - z; break;
                case 270: nx = z; nz = oldW - 1 - x; break;
                default: return;
            }
            int newIndex = index(nx, y, nz, newW, newL);
            newIds[newIndex] = blocks_id[oldIndex];
            if (newWideIds != null) newWideIds[newIndex] = wide_ids[oldIndex];
            newData[newIndex] = rotateLegacyMetadata(getBlockIdAt(oldIndex), blocks_data[oldIndex], angle);
        }
        blocks_id = newIds;
        wide_ids = newWideIds;
        blocks_data = newData;
        width = newW;
        height = oldH;
        length = newL;
    }

    private int getBlockIdAt(int index) { return wide_ids == null ? blocks_id[index] & 0xff : wide_ids[index] & 0xffff; }
    private static int index(int x, int y, int z, int width, int length) { return x + z * width + y * width * length; }

    private byte rotateLegacyMetadata(int id, byte raw, int angle) {
        int meta = raw & 0xff;
        if (id == 53 || id == 67 || id == 108 || id == 109 || id == 114 || id == 128 || id == 134 || id == 135 || id == 136 || id == 156 || id == 163 || id == 164 || id == 180 || id == 203) {
            // Legacy stair metadata direction codes: east, west, south, north; preserve upside-down bit.
            int high = meta & 4;
            int d = meta & 3;
            for (int i = 0; i < (angle / 90); i++) {
                if (d == 0) d = 2; else if (d == 1) d = 3; else if (d == 2) d = 1; else d = 0;
            }
            return (byte) (high | d);
        }
        if (id == 17 || id == 162) {
            int axis = meta & 12;
            if (axis == 4 || axis == 8) meta = (meta & 3) | ((axis == 4) ? 8 : 4);
        }
        return (byte) meta;
    }

    public int getWidth() { return width; }
    public int getLength() { return length; }
    public int getHeight() { return height; }
    public int getBlockId(int x, int y, int z) { return getBlockIdAt(index(x, y, z, width, length)); }
    public byte getBlockData(int x, int y, int z) { return blocks_data[index(x, y, z, width, length)]; }
}
