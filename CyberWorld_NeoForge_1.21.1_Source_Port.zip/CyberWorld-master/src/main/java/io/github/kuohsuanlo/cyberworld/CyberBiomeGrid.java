package io.github.kuohsuanlo.cyberworld;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.biome.BiomeSource;
import net.minecraft.world.level.levelgen.RandomState;

/** Read-only 16x16 biome view matching the coordinates the Bukkit generator originally expected. */
public final class CyberBiomeGrid {
    private final BiomeSource source;
    private final net.minecraft.world.level.levelgen.RandomState randomState;
    private final int chunkX, chunkZ;
    private final Biome[][] cache = new Biome[16][16];
    public CyberBiomeGrid(BiomeSource source, RandomState randomState, int chunkX, int chunkZ) {
        this.source = source; this.randomState = randomState; this.chunkX = chunkX; this.chunkZ = chunkZ;
    }
    public Biome getBiome(int x, int z) {
        x = Math.max(0, Math.min(15, x)); z = Math.max(0, Math.min(15, z));
        Biome found = cache[x][z];
        if (found != null) return found;
        int absoluteX = (chunkX << 4) + x;
        int absoluteZ = (chunkZ << 4) + z;
        var holder = source.getNoiseBiome(absoluteX >> 2, 16, absoluteZ >> 2, randomState.sampler());
        var key = BuiltInRegistries.BIOME.getKey(holder.value());
        found = key == null ? Biome.PLAINS : Biome.fromModernName(key.getPath());
        cache[x][z] = found;
        return found;
    }
}
