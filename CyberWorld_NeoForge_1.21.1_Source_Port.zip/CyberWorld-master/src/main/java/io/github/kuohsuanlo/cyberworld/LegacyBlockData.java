package io.github.kuohsuanlo.cyberworld;

import net.minecraft.world.level.block.state.BlockState;

/** Original schematic block id plus pre-1.13 metadata. */
public final class LegacyBlockData {
    private final int id;
    private final byte data;
    public LegacyBlockData(int id) { this(id, (byte) 0); }
    public LegacyBlockData(int id, byte data) { this.id=id; this.data=data; }
    public LegacyBlockData(Material material) { this(LegacyBlocks.idForModern(material), (byte)0); }
    public int getId() { return id; }
    public byte getData() { return data; }
    public Material getMaterial() { return LegacyBlocks.materialFor(id,data); }
    public BlockState toBlockData() { return LegacyBlocks.toBlockData(id,data); }
}
