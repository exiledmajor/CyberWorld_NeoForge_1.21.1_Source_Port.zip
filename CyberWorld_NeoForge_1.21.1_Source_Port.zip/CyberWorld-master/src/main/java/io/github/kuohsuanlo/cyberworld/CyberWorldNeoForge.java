package io.github.kuohsuanlo.cyberworld;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.function.Supplier;

@Mod(CyberWorldNeoForge.MOD_ID)
public final class CyberWorldNeoForge {
    public static final String MOD_ID = "cyberworld";
    public static final DeferredRegister<MapCodec<? extends ChunkGenerator>> CHUNK_GENERATORS =
            DeferredRegister.create(BuiltInRegistries.CHUNK_GENERATOR, MOD_ID);
    public static final Supplier<MapCodec<CyberWorldChunkGenerator>> CYBERWORLD_GENERATOR =
            CHUNK_GENERATORS.register("cyberworld", () -> CyberWorldChunkGenerator.CODEC);

    public CyberWorldNeoForge(IEventBus modEventBus, ModContainer modContainer) {
        CHUNK_GENERATORS.register(modEventBus);
        CyberWorld.getInstance();
    }
}
