package io.github.kuohsuanlo.cyberworld;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.GZIPInputStream;

/** Reads classic MCEdit .schematic NBT files without a WorldEdit runtime dependency. */
public final class Schematic {
    public static final class Data {
        public final int width, height, length;
        /** Low byte of each block ID. Used by virtually all pre-1.13 schematics. */
        public final byte[] ids;
        /** Allocated only when the source file uses IDs above 255. */
        public final short[] wideIds;
        public final byte[] data;

        Data(int width, int height, int length, byte[] rawIds, byte[] rawData, byte[] addBlocks) {
            if (width <= 0 || height <= 0 || length <= 0) throw new IllegalArgumentException("Invalid schematic size");
            long volumeLong = (long) width * height * length;
            if (volumeLong > 32_000_000L || volumeLong > rawIds.length || volumeLong > rawData.length) {
                throw new IllegalArgumentException("Schematic dimensions do not match block arrays");
            }
            int volume = (int) volumeLong;
            this.width = width;
            this.height = height;
            this.length = length;
            ids = new byte[volume];
            data = new byte[volume];

            boolean requiresWideIds = false;
            if (addBlocks != null) {
                int checkLength = Math.min((volume + 1) / 2, addBlocks.length);
                for (int i = 0; i < checkLength; i++) {
                    if ((addBlocks[i] & 0xff) != 0) { requiresWideIds = true; break; }
                }
            }
            wideIds = requiresWideIds ? new short[volume] : null;
            for (int i = 0; i < volume; i++) {
                int id = rawIds[i] & 0xff;
                if (addBlocks != null && i / 2 < addBlocks.length) {
                    int extra = addBlocks[i / 2] & 0xff;
                    id |= ((i & 1) == 0 ? extra & 0x0f : (extra >>> 4) & 0x0f) << 8;
                }
                ids[i] = (byte) id;
                if (wideIds != null) wideIds[i] = (short) id;
                data[i] = rawData[i];
            }
        }

        public int getId(int index) { return wideIds == null ? (ids[index] & 0xff) : (wideIds[index] & 0xffff); }
        public int volume() { return ids.length; }
    }

    public Data getSchematic(String fileName) {
        Path path = Path.of(fileName);
        if (!Files.isRegularFile(path) || !fileName.toLowerCase(java.util.Locale.ROOT).endsWith(".schematic")) return null;
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(new GZIPInputStream(Files.newInputStream(path))))) {
            int rootType = in.readUnsignedByte();
            if (rootType != 10) throw new IOException("Schematic root is not an NBT compound");
            in.readUTF(); // root name
            Map<String, Object> root = readCompound(in);
            int w = number(root.get("Width"));
            int h = number(root.get("Height"));
            int l = number(root.get("Length"));
            Object blocks = root.get("Blocks");
            Object blockData = root.get("Data");
            if (!(blocks instanceof byte[]) || !(blockData instanceof byte[])) {
                throw new IOException("Schematic is missing legacy Blocks/Data arrays");
            }
            return new Data(w, h, l, (byte[]) blocks, (byte[]) blockData,
                    root.get("AddBlocks") instanceof byte[] ? (byte[]) root.get("AddBlocks") : null);
        } catch (Exception ex) {
            System.err.println("[CyberWorld] Could not read schematic " + fileName + ": " + ex.getMessage());
            return null;
        }
    }

    private static int number(Object value) throws IOException {
        if (value instanceof Number) return ((Number) value).intValue();
        throw new IOException("Missing/invalid schematic dimension");
    }

    private static Map<String, Object> readCompound(DataInputStream in) throws IOException {
        Map<String, Object> out = new LinkedHashMap<>();
        while (true) {
            int type = in.readUnsignedByte();
            if (type == 0) return out;
            String name = in.readUTF();
            out.put(name, readPayload(in, type));
        }
    }

    private static Object readPayload(DataInputStream in, int type) throws IOException {
        switch (type) {
            case 1: return in.readByte();
            case 2: return in.readShort();
            case 3: return in.readInt();
            case 4: return in.readLong();
            case 5: return in.readFloat();
            case 6: return in.readDouble();
            case 7: {
                int size = checkedSize(in.readInt());
                byte[] bytes = new byte[size]; in.readFully(bytes); return bytes;
            }
            case 8: return in.readUTF();
            case 9: {
                int childType = in.readUnsignedByte();
                int size = checkedSize(in.readInt());
                List<Object> list = new ArrayList<>(Math.min(size, 100_000));
                if (size == 0) return list;
                for (int i = 0; i < size; i++) list.add(readPayload(in, childType));
                return list;
            }
            case 10: return readCompound(in);
            case 11: {
                int size = checkedSize(in.readInt()); int[] a = new int[size];
                for (int i = 0; i < size; i++) a[i] = in.readInt(); return a;
            }
            case 12: {
                int size = checkedSize(in.readInt()); long[] a = new long[size];
                for (int i = 0; i < size; i++) a[i] = in.readLong(); return a;
            }
            default: throw new IOException("Unknown NBT tag type: " + type);
        }
    }

    private static int checkedSize(int size) throws IOException {
        if (size < 0 || size > 32_000_000) throw new IOException("Invalid NBT array/list size: " + size);
        return size;
    }
}
