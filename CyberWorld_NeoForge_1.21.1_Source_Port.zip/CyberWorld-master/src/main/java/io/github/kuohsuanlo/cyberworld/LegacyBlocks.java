package io.github.kuohsuanlo.cyberworld;

import net.minecraft.core.Direction;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.Half;
import net.minecraft.world.level.block.state.properties.SlabType;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** Converts CyberWorld's original pre-1.13 IDs and metadata to 1.21.1 blockstates. */
public final class LegacyBlocks {
    private static final Map<String, Integer> NAME_TO_ID = new HashMap<>();
    private static final String[] COLORS = {"WHITE", "ORANGE", "MAGENTA", "LIGHT_BLUE", "YELLOW", "LIME", "PINK", "GRAY", "LIGHT_GRAY", "CYAN", "PURPLE", "BLUE", "BROWN", "GREEN", "RED", "BLACK"};
    static {

        add("AIR",0); add("STONE",1); add("GRASS",2); add("DIRT",3); add("COBBLESTONE",4); add("WOOD",5); add("BEDROCK",7);
        add("WATER",8); add("STATIONARY_WATER",9); add("LAVA",10); add("STATIONARY_LAVA",11); add("SAND",12); add("GRAVEL",13);
        add("GOLD_ORE",14); add("IRON_ORE",15); add("COAL_ORE",16); add("LOG",17); add("LEAVES",18); add("GLASS",20);
        add("LAPIS_ORE",21); add("LAPIS_BLOCK",22); add("SANDSTONE",24); add("WOOL",35); add("GOLD_BLOCK",41); add("IRON_BLOCK",42);
        add("DOUBLE_STEP",43); add("STEP",44); add("BRICK",45); add("TNT",46); add("MOSSY_COBBLESTONE",48); add("OBSIDIAN",49);
        add("WOOD_STAIRS",53); add("DIAMOND_BLOCK",57); add("FURNACE",61); add("COBBLESTONE_STAIRS",67); add("REDSTONE_ORE",73);
        add("GLOWING_REDSTONE_ORE",74); add("SNOW",78); add("ICE",79); add("SNOW_BLOCK",80); add("CLAY",82); add("FENCE",85);
        add("NETHERRACK",87); add("SOUL_SAND",88); add("GLOWSTONE",89); add("JACK_O_LANTERN",91); add("STAINED_GLASS",95);
        add("TRAP_DOOR",96); add("SMOOTH_BRICK",98); add("IRON_FENCE",101); add("THIN_GLASS",102); add("BRICK_STAIRS",108);
        add("SMOOTH_STAIRS",109); add("NETHER_FENCE",113); add("NETHER_BRICK_STAIRS",114); add("ENDER_STONE",121); add("WOOD_DOUBLE_STEP",125);
        add("WOOD_STEP",126); add("SANDSTONE_STAIRS",128); add("EMERALD_ORE",129); add("EMERALD_BLOCK",133); add("SPRUCE_WOOD_STAIRS",134);
        add("BIRCH_WOOD_STAIRS",135); add("JUNGLE_WOOD_STAIRS",136); add("BEACON",138); add("ANVIL",145); add("TRAPPED_CHEST",146);
        add("REDSTONE_BLOCK",152); add("QUARTZ_BLOCK",155); add("QUARTZ_STAIRS",156); add("STAINED_CLAY",159); add("STAINED_GLASS_PANE",160);
        add("LEAVES_2",161); add("LOG_2",162); add("ACACIA_STAIRS",163); add("DARK_OAK_STAIRS",164); add("IRON_TRAPDOOR",167);
        add("PRISMARINE",168); add("SEA_LANTERN",169); add("CARPET",171); add("FROSTED_ICE",212); add("HARD_CLAY",172); add("COAL_BLOCK",173); add("PACKED_ICE",174);
        add("RED_SANDSTONE",179); add("RED_SANDSTONE_STAIRS",180); add("DOUBLE_STONE_SLAB2",181); add("SPRUCE_FENCE",188);
        add("BIRCH_FENCE",189); add("JUNGLE_FENCE",190); add("DARK_OAK_FENCE",191); add("ACACIA_FENCE",192); add("PURPUR_BLOCK",201);
        add("PURPUR_PILLAR",202); add("PURPUR_STAIRS",203); add("PURPUR_DOUBLE_SLAB",204); add("PURPUR_SLAB",205); add("END_BRICKS",206);
        add("COMMAND",137); add("COMMAND_CHAIN",211); add("COMMAND_REPEATING",210); add("COMMAND_MINECART",422);
    
    }
    private LegacyBlocks() { }
    private static void add(String legacyName, int id) { NAME_TO_ID.put(legacyName, id); }
    public static int id(String legacyName) {
        Integer id = NAME_TO_ID.get(legacyName.toUpperCase(Locale.ROOT));
        if (id != null) return id;
        return switch (legacyName.toUpperCase(Locale.ROOT)) {
            case "AIR", "CAVE_AIR", "VOID_AIR" -> 0;
            case "GRASS_BLOCK", "GRASS" -> 2;
            case "STONE" -> 1;
            case "DIRT" -> 3;
            case "COBBLESTONE" -> 4;
            case "GLASS" -> 20;
            case "QUARTZ_BLOCK" -> 155;
            default -> 1;
        };
    }
    public static int idForModern(Material material) {
        String name = material.name();
        Integer exact = NAME_TO_ID.get(name);
        if (exact != null) return exact;
        return switch (name) {
            case "AIR", "CAVE_AIR", "VOID_AIR" -> 0;
            case "STONE" -> 1; case "GRASS_BLOCK" -> 2; case "DIRT" -> 3;
            case "COBBLESTONE" -> 4; case "GLASS" -> 20; case "QUARTZ_BLOCK" -> 155;
            case "IRON_BARS" -> 101; case "STONE_SLAB" -> 44; case "OAK_FENCE" -> 85;
            default -> 1;
        };
    }
    public static Material materialFor(int id, byte data) {
        String name = modernName(id, data);
        return Material.byName(name == null ? "STONE" : name);
    }
    public static BlockState toBlockData(int id, byte rawData) {
        int d = rawData & 0xff;
        BlockState state = materialFor(id, rawData).defaultBlockState();
        try {
            if (isStairs(id) && state.hasProperty(BlockStateProperties.HORIZONTAL_FACING)) {
                Direction facing = switch (d & 3) { case 0 -> Direction.EAST; case 1 -> Direction.WEST; case 2 -> Direction.SOUTH; default -> Direction.NORTH; };
                state = state.setValue(BlockStateProperties.HORIZONTAL_FACING, facing);
                if (state.hasProperty(BlockStateProperties.HALF)) state = state.setValue(BlockStateProperties.HALF, (d & 4) != 0 ? Half.TOP : Half.BOTTOM);
            } else if (isSlab(id) && state.hasProperty(BlockStateProperties.SLAB_TYPE)) {
                state = state.setValue(BlockStateProperties.SLAB_TYPE, (d & 8) != 0 ? SlabType.TOP : SlabType.BOTTOM);
            } else if ((id == 17 || id == 162) && state.hasProperty(BlockStateProperties.AXIS)) {
                int axis = d & 12;
                state = state.setValue(BlockStateProperties.AXIS, axis == 4 ? Direction.Axis.X : axis == 8 ? Direction.Axis.Z : Direction.Axis.Y);
            } else if ((id == 96 || id == 167) && state.hasProperty(BlockStateProperties.HORIZONTAL_FACING)) {
                Direction facing = switch (d & 3) { case 0 -> Direction.SOUTH; case 1 -> Direction.NORTH; case 2 -> Direction.EAST; default -> Direction.WEST; };
                state = state.setValue(BlockStateProperties.HORIZONTAL_FACING, facing);
                if (state.hasProperty(BlockStateProperties.OPEN)) state = state.setValue(BlockStateProperties.OPEN, (d & 4) != 0);
                if (state.hasProperty(BlockStateProperties.HALF)) state = state.setValue(BlockStateProperties.HALF, (d & 8) != 0 ? Half.TOP : Half.BOTTOM);
            } else if ((id == 64 || id == 71 || (id >= 193 && id <= 197)) && state.hasProperty(BlockStateProperties.HORIZONTAL_FACING)) {
                Direction facing = switch (d & 3) { case 0 -> Direction.EAST; case 1 -> Direction.SOUTH; case 2 -> Direction.WEST; default -> Direction.NORTH; };
                state = state.setValue(BlockStateProperties.HORIZONTAL_FACING, facing);
                if (state.hasProperty(BlockStateProperties.OPEN)) state = state.setValue(BlockStateProperties.OPEN, (d & 4) != 0);
                if (state.hasProperty(BlockStateProperties.HALF)) state = state.setValue(BlockStateProperties.HALF, (d & 8) != 0 ? Half.TOP : Half.BOTTOM);
            } else if (id == 78 && state.hasProperty(BlockStateProperties.LAYERS)) {
                state = state.setValue(BlockStateProperties.LAYERS, Math.max(1, Math.min(8, d & 7)));
            }
        } catch (IllegalArgumentException ignored) { }
        return state;
    }
    private static boolean isStairs(int id) { return id == 53 || id == 67 || id == 108 || id == 109 || id == 114 || id == 128 || id == 134 || id == 135 || id == 136 || id == 156 || id == 163 || id == 164 || id == 180 || id == 203; }
    private static boolean isSlab(int id) { return id == 44 || id == 126 || id == 182 || id == 205; }
    private static String modernName(int id, byte raw) {
        int d = raw & 0xff;
        if (id == 35) return COLORS[d & 15] + "_WOOL";
        if (id == 95) return COLORS[d & 15] + "_STAINED_GLASS";
        if (id == 160) return COLORS[d & 15] + "_STAINED_GLASS_PANE";
        if (id == 159) return COLORS[d & 15] + "_TERRACOTTA";
        if (id == 171) return COLORS[d & 15] + "_CARPET";
        switch (id) {
            case 6: return new String[]{"OAK_SAPLING","SPRUCE_SAPLING","BIRCH_SAPLING","JUNGLE_SAPLING","ACACIA_SAPLING","DARK_OAK_SAPLING"}[Math.min(d & 7,5)];
            case 19: return (d & 1) == 0 ? "SPONGE" : "WET_SPONGE";
            case 23: return "DISPENSER"; case 25: return "NOTE_BLOCK"; case 26: return "RED_BED"; case 27: return "POWERED_RAIL";
            case 28: return "DETECTOR_RAIL"; case 29: return "STICKY_PISTON"; case 30: return "COBWEB";
            case 31: return d == 0 ? "DEAD_BUSH" : d == 2 ? "FERN" : "SHORT_GRASS";
            case 32: return "DEAD_BUSH"; case 33: return "PISTON"; case 34: return "PISTON_HEAD";
            case 37: return "DANDELION";
            case 38: return new String[]{"POPPY","BLUE_ORCHID","ALLIUM","AZURE_BLUET","RED_TULIP","ORANGE_TULIP","WHITE_TULIP","PINK_TULIP","OXEYE_DAISY"}[Math.min(d,8)];
            case 39: return "BROWN_MUSHROOM"; case 40: return "RED_MUSHROOM"; case 47: return "BOOKSHELF"; case 50: return "TORCH"; case 51: return "FIRE";
            case 52: return "SPAWNER"; case 54: return "CHEST"; case 55: return "REDSTONE_WIRE"; case 56: return "DIAMOND_ORE";
            case 58: return "CRAFTING_TABLE"; case 59: return "WHEAT"; case 60: return "FARMLAND"; case 63: return "OAK_SIGN";
            case 64: return "OAK_DOOR"; case 65: return "LADDER"; case 66: return "RAIL"; case 68: return "OAK_WALL_SIGN";
            case 69: return "LEVER"; case 70: return "STONE_PRESSURE_PLATE"; case 71: return "IRON_DOOR"; case 72: return "OAK_PRESSURE_PLATE";
            case 75: case 76: return "REDSTONE_TORCH"; case 77: return "STONE_BUTTON"; case 81: return "CACTUS"; case 83: return "SUGAR_CANE";
            case 84: return "JUKEBOX"; case 86: return "PUMPKIN"; case 90: return "NETHER_PORTAL"; case 92: return "CAKE";
            case 93: case 94: return "REPEATER"; case 97: return new String[]{"INFESTED_STONE","INFESTED_COBBLESTONE","INFESTED_STONE_BRICKS","INFESTED_MOSSY_STONE_BRICKS","INFESTED_CRACKED_STONE_BRICKS","INFESTED_CHISELED_STONE_BRICKS"}[Math.min(d & 7,5)];
            case 99: return "BROWN_MUSHROOM_BLOCK"; case 100: return "RED_MUSHROOM_BLOCK"; case 103: return "MELON"; case 106: return "VINE";
            case 107: return "OAK_FENCE_GATE"; case 110: return "MYCELIUM"; case 111: return "LILY_PAD"; case 112: return "NETHER_BRICKS";
            case 116: return "ENCHANTING_TABLE"; case 117: return "BREWING_STAND"; case 118: return "CAULDRON"; case 120: return "END_PORTAL_FRAME";
            case 122: return "DRAGON_EGG"; case 123: case 124: return "REDSTONE_LAMP"; case 127: return "COCOA"; case 130: return "ENDER_CHEST";
            case 131: return "TRIPWIRE_HOOK"; case 132: return "TRIPWIRE"; case 139: return (d & 1) == 0 ? "COBBLESTONE_WALL" : "MOSSY_COBBLESTONE_WALL";
            case 140: return "FLOWER_POT"; case 141: return "CARROTS"; case 142: return "POTATOES"; case 143: return "OAK_BUTTON"; case 144: return "SKELETON_SKULL";
            case 147: return "LIGHT_WEIGHTED_PRESSURE_PLATE"; case 148: return "HEAVY_WEIGHTED_PRESSURE_PLATE"; case 149: case 150: return "COMPARATOR";
            case 151: case 178: return "DAYLIGHT_DETECTOR"; case 153: return "NETHER_QUARTZ_ORE"; case 154: return "HOPPER"; case 157: return "ACTIVATOR_RAIL"; case 158: return "DROPPER";
            case 165: return "SLIME_BLOCK"; case 166: return "BARRIER"; case 170: return "HAY_BLOCK";
            case 175: return new String[]{"SUNFLOWER","LILAC","TALL_GRASS","LARGE_FERN","ROSE_BUSH","PEONY"}[Math.min(d & 7,5)];
            case 176: return "WHITE_BANNER"; case 177: return "WHITE_WALL_BANNER"; case 182: return "RED_SANDSTONE_SLAB";
            case 183: return "SPRUCE_FENCE_GATE"; case 184: return "BIRCH_FENCE_GATE"; case 185: return "JUNGLE_FENCE_GATE"; case 186: return "DARK_OAK_FENCE_GATE"; case 187: return "ACACIA_FENCE_GATE";
            case 193: return "SPRUCE_DOOR"; case 194: return "BIRCH_DOOR"; case 195: return "JUNGLE_DOOR"; case 196: return "ACACIA_DOOR"; case 197: return "DARK_OAK_DOOR";
            case 198: return "END_ROD"; case 199: return "CHORUS_PLANT"; case 200: return "CHORUS_FLOWER"; case 207: return "BEETROOTS"; case 208: return "DIRT_PATH";
            case 209: return "END_GATEWAY"; case 212: return "FROSTED_ICE"; case 213: return "MAGMA_BLOCK"; case 214: return "NETHER_WART_BLOCK"; case 215: return "RED_NETHER_BRICKS";
            case 0: return "AIR"; case 1: return "STONE"; case 2: return "GRASS_BLOCK"; case 3: return "DIRT"; case 4: return "COBBLESTONE";
            case 5: return new String[]{"OAK_PLANKS","SPRUCE_PLANKS","BIRCH_PLANKS","JUNGLE_PLANKS","ACACIA_PLANKS","DARK_OAK_PLANKS"}[Math.min(d & 7,5)];
            case 7: return "BEDROCK"; case 8: case 9: return "WATER"; case 10: case 11: return "LAVA"; case 12: return (d & 1) != 0 ? "RED_SAND" : "SAND";
            case 13: return "GRAVEL"; case 14: return "GOLD_ORE"; case 15: return "IRON_ORE"; case 16: return "COAL_ORE";
            case 17: return new String[]{"OAK_LOG","SPRUCE_LOG","BIRCH_LOG","JUNGLE_LOG"}[d & 3];
            case 18: return new String[]{"OAK_LEAVES","SPRUCE_LEAVES","BIRCH_LEAVES","JUNGLE_LEAVES"}[d & 3];
            case 20: return "GLASS"; case 21: return "LAPIS_ORE"; case 22: return "LAPIS_BLOCK"; case 24: return "SANDSTONE";
            case 41: return "GOLD_BLOCK"; case 42: return "IRON_BLOCK"; case 43: return new String[]{"STONE","SANDSTONE","OAK_PLANKS","COBBLESTONE","BRICKS","STONE_BRICKS","NETHER_BRICKS","QUARTZ_BLOCK"}[Math.min(d & 7,7)];
            case 44: return new String[]{"STONE_SLAB","SANDSTONE_SLAB","PETRIFIED_OAK_SLAB","COBBLESTONE_SLAB","BRICK_SLAB","STONE_BRICK_SLAB","NETHER_BRICK_SLAB","QUARTZ_SLAB"}[Math.min(d & 7,7)];
            case 45: return "BRICKS"; case 46: return "TNT"; case 48: return "MOSSY_COBBLESTONE"; case 49: return "OBSIDIAN";
            case 53: return "OAK_STAIRS"; case 57: return "DIAMOND_BLOCK"; case 61: return "FURNACE"; case 67: return "COBBLESTONE_STAIRS";
            case 73: case 74: return "REDSTONE_ORE"; case 78: return "SNOW"; case 79: return "ICE"; case 80: return "SNOW_BLOCK"; case 82: return "CLAY";
            case 85: return "OAK_FENCE"; case 87: return "NETHERRACK"; case 88: return "SOUL_SAND"; case 89: return "GLOWSTONE"; case 91: return "JACK_O_LANTERN";
            case 96: return "OAK_TRAPDOOR"; case 98: return new String[]{"STONE_BRICKS","MOSSY_STONE_BRICKS","CRACKED_STONE_BRICKS","CHISELED_STONE_BRICKS"}[Math.min(d & 3,3)];
            case 101: return "IRON_BARS"; case 102: return "GLASS_PANE"; case 108: return "BRICK_STAIRS"; case 109: return "STONE_BRICK_STAIRS";
            case 113: return "NETHER_BRICK_FENCE"; case 114: return "NETHER_BRICK_STAIRS"; case 121: return "END_STONE"; case 125: return new String[]{"OAK_PLANKS","SPRUCE_PLANKS","BIRCH_PLANKS","JUNGLE_PLANKS","ACACIA_PLANKS","DARK_OAK_PLANKS"}[Math.min(d & 7,5)];
            case 126: return new String[]{"OAK_SLAB","SPRUCE_SLAB","BIRCH_SLAB","JUNGLE_SLAB","ACACIA_SLAB","DARK_OAK_SLAB"}[Math.min(d & 7,5)];
            case 128: return "SANDSTONE_STAIRS"; case 129: return "EMERALD_ORE"; case 133: return "EMERALD_BLOCK"; case 134: return "SPRUCE_STAIRS"; case 135: return "BIRCH_STAIRS"; case 136: return "JUNGLE_STAIRS";
            case 138: return "BEACON"; case 145: return "ANVIL"; case 146: return "TRAPPED_CHEST"; case 152: return "REDSTONE_BLOCK"; case 155: return new String[]{"QUARTZ_BLOCK","CHISELED_QUARTZ_BLOCK","QUARTZ_PILLAR","QUARTZ_BLOCK"}[Math.min(d & 3,3)];
            case 156: return "QUARTZ_STAIRS"; case 161: return new String[]{"ACACIA_LEAVES","DARK_OAK_LEAVES"}[d & 1]; case 162: return new String[]{"ACACIA_LOG","DARK_OAK_LOG"}[d & 1];
            case 163: return "ACACIA_STAIRS"; case 164: return "DARK_OAK_STAIRS"; case 167: return "IRON_TRAPDOOR"; case 168: return new String[]{"PRISMARINE","PRISMARINE_BRICKS","DARK_PRISMARINE"}[Math.min(d & 3,2)]; case 169: return "SEA_LANTERN";
            case 172: return "TERRACOTTA"; case 173: return "COAL_BLOCK"; case 174: return "PACKED_ICE"; case 179: return "RED_SANDSTONE"; case 180: return "RED_SANDSTONE_STAIRS";
            case 181: return (d & 7) == 0 ? "RED_SANDSTONE" : "STONE"; case 188: return "SPRUCE_FENCE"; case 189: return "BIRCH_FENCE"; case 190: return "JUNGLE_FENCE"; case 191: return "DARK_OAK_FENCE"; case 192: return "ACACIA_FENCE";
            case 201: return "PURPUR_BLOCK"; case 202: return "PURPUR_PILLAR"; case 203: return "PURPUR_STAIRS"; case 204: return "PURPUR_BLOCK"; case 205: return "PURPUR_SLAB"; case 206: return "END_STONE_BRICKS";
            case 137: return "COMMAND_BLOCK"; case 210: return "REPEATING_COMMAND_BLOCK"; case 211: return "CHAIN_COMMAND_BLOCK";
            default: return null;
        }
    }

    public static void set(CyberChunkData chunk, int x, int y, int z, Material material) {
        if (inBounds(chunk,x,y,z)) chunk.setBlock(x,y,z,material);
    }
    public static void set(CyberChunkData chunk, int x, int y, int z, BlockState state) {
        if (inBounds(chunk,x,y,z)) chunk.setBlock(x,y,z,state);
    }
    private static boolean inBounds(CyberChunkData chunk, int x, int y, int z) {
        return x >= 0 && x < 16 && z >= 0 && z < 16 && y >= chunk.getMinHeight() && y < chunk.getMaxHeight();
    }
    public static void set(CyberChunkData chunk, int x, int y, int z, LegacyBlockData data) { set(chunk,x,y,z,data.toBlockData()); }
    public static void set(CyberChunkData chunk, int x, int y, int z, int id, byte data) { set(chunk,x,y,z,new LegacyBlockData(id,data)); }
    public static void set(CyberChunkData chunk, int x, int y, int z, int id) { set(chunk,x,y,z,new LegacyBlockData(id)); }
    public static void setRegion(CyberChunkData chunk, int x1, int y1, int z1, int x2, int y2, int z2, Material material) {
        chunk.setRegion(x1,y1,z1,x2,y2,z2,material);
    }
    public static void setRegion(CyberChunkData chunk, int x1, int y1, int z1, int x2, int y2, int z2, LegacyBlockData data) {
        int minY=Math.max(y1,chunk.getMinHeight()), maxY=Math.min(y2,chunk.getMaxHeight());
        for (int x=Math.max(0,x1);x<Math.min(16,x2);x++) for (int y=minY;y<maxY;y++) for (int z=Math.max(0,z1);z<Math.min(16,z2);z++) set(chunk,x,y,z,data);
    }

}
