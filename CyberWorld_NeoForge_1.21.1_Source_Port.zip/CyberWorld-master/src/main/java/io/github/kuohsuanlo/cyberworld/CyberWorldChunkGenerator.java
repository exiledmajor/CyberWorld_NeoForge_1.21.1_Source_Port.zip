package io.github.kuohsuanlo.cyberworld;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.LevelHeightAccessor;
import net.minecraft.world.level.NoiseColumn;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.biome.BiomeManager;
import net.minecraft.world.level.biome.BiomeSource;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.RandomState;
import net.minecraft.world.level.levelgen.blending.Blender;
import net.minecraft.server.level.WorldGenRegion;
import net.minecraft.util.RandomSource;

import java.util.List;
import java.util.concurrent.CompletableFuture;

/** Native NeoForge generator codec for the original CyberWorld city algorithm. */
public final class CyberWorldChunkGenerator extends ChunkGenerator {
    public static final MapCodec<CyberWorldChunkGenerator> CODEC = RecordCodecBuilder.mapCodec(instance ->
            instance.group(BiomeSource.CODEC.fieldOf("biome_source").forGetter(generator -> generator.biomeSource))
                    .apply(instance, CyberWorldChunkGenerator::new));
    private static volatile CyberWorldObjectGenerator objectGenerator;
    private static final CyberWorldBiomeGenerator BIOME_GENERATOR = new CyberWorldBiomeGenerator(3, 5);

    public CyberWorldChunkGenerator(BiomeSource biomeSource) { super(biomeSource); }
    private static CyberWorldObjectGenerator objects() {
        CyberWorldObjectGenerator current=objectGenerator;
        if (current==null) synchronized (CyberWorldChunkGenerator.class) {
            if (objectGenerator==null) {
                CyberWorld config=CyberWorld.getInstance();
                objectGenerator=new CyberWorldObjectGenerator(config, config.BIOME_TYPES, BIOME_GENERATOR, null);
            }
            current=objectGenerator;
        }
        return current;
    }
    @Override protected MapCodec<? extends ChunkGenerator> codec() { return CODEC; }

    @Override
    public CompletableFuture<ChunkAccess> fillFromNoise(Blender blender, RandomState randomState, StructureManager structureManager, ChunkAccess chunk) {
        return CompletableFuture.supplyAsync(() -> {
            synchronized (CyberWorldChunkGenerator.class) {
                int cx=chunk.getPos().x, cz=chunk.getPos().z;
                CyberWorld config=CyberWorld.getInstance();
                CyberWorldObjectGenerator og=objects();
                CyberChunkData data=new CyberChunkData();
                CyberBiomeGrid biomes=new CyberBiomeGrid(biomeSource,randomState,cx,cz);
                int biomeType=internalBiomeType(cx,cz);
                RandomSource mcRandom=RandomSource.create((((long)cx)<<32) ^ (cz&0xffffffffL) ^ 0x4359424552574f52L);
                java.util.Random random=new java.util.Random(mcRandom.nextLong());
                if (biomeType < config.BIOME_NUMBER_WITH_BUILDING) {
                    data=og.generateBottom(data,random,cx,cz,biomeType,biomes);
                    data=og.generateCitySurface(data,random,cx,cz,biomeType,biomes);
                    data=og.generateCityRoad(data,random,cx,cz,biomeType,biomes);
                    data=og.generateCitySewer(data,random,cx,cz,biomeType,biomes);
                    data=og.generateGroundDecoration(data,random,cx,cz,biomeType,biomes);
                    data=og.generateBuilding(data,random,cx,cz,biomeType,biomes,2,false);
                    data=og.generateGroundSign(data,random,cx,cz,biomeType,biomes);
                    data=og.generateUnderGroundBuilding(data,random,cx,cz,biomeType,biomes,2);
                    data=og.generateHighway(data,random,cx,cz,biomeType,biomes);
                } else {
                    data=og.generateBottom(data,random,cx,cz,biomeType,biomes);
                    data=og.generateTerrain(data,random,cx,cz,biomeType,biomes);
                    data=og.generateFactoryGround(data,random,cx,cz,biomeType,biomes);
                    data=og.generateCityRoad(data,random,cx,cz,biomeType,biomes);
                    data=og.generateFactorySewer(data,random,cx,cz,biomeType,biomes);
                }
                BlockPos.MutableBlockPos pos=new BlockPos.MutableBlockPos();
                for (int y=CyberChunkData.MIN_Y; y<CyberChunkData.MAX_Y; y++) {
                    for (int z=0;z<16;z++) for (int x=0;x<16;x++) {
                        BlockState state=data.getStoredBlockState(x,y,z);
                        if (state != null) chunk.setBlockState(pos.set((cx<<4)+x,y,(cz<<4)+z),state,false);
                    }
                }
                return chunk;
            }
        }, net.minecraft.Util.backgroundExecutor());
    }

    @Override public void applyCarvers(WorldGenRegion level, long seed, RandomState random, BiomeManager biomeManager, StructureManager structureManager, ChunkAccess chunk, GenerationStep.Carving step) { }
    @Override public void buildSurface(WorldGenRegion level, StructureManager structureManager, RandomState random, ChunkAccess chunk) { }
    @Override public void spawnOriginalMobs(WorldGenRegion level) { }
    @Override public void applyBiomeDecoration(WorldGenLevel level, ChunkAccess chunk, StructureManager structureManager) { }
    @Override public void addDebugScreenInfo(List<String> info, RandomState random, BlockPos pos) { info.add("CyberWorld procedural city generation"); }
    @Override public int getGenDepth() { return 384; }
    @Override public int getMinY() { return -64; }
    @Override public int getSeaLevel() { return CyberWorld.getInstance().SEA_LEVEL; }

    private static synchronized int internalBiomeType(int chunkX, int chunkZ) { return BIOME_GENERATOR.generateType(chunkX, chunkZ, true); }
    @Override public int getBaseHeight(int x, int z, Heightmap.Types type, LevelHeightAccessor height, RandomState random) {
        int biomeType=internalBiomeType(x>>4,z>>4);
        return biomeType < CyberWorld.getInstance().BIOME_NUMBER_WITH_BUILDING ? CyberWorld.getInstance().GROUND_LEVEL+4 : CyberWorld.getInstance().GROUND_LEVEL+20;
    }
    @Override public NoiseColumn getBaseColumn(int x, int z, LevelHeightAccessor height, RandomState random) {
        int minY=height.getMinBuildHeight(), maxY=height.getMaxBuildHeight();
        BlockState[] states=new BlockState[maxY-minY];
        java.util.Arrays.fill(states, Blocks.AIR.defaultBlockState());
        int base=CyberWorld.getInstance().GROUND_LEVEL;
        if (base-1>=minY && base-1<maxY) states[base-1-minY]=Blocks.STONE.defaultBlockState();
        if (base>=minY && base<maxY) states[base-minY]=Blocks.GRASS_BLOCK.defaultBlockState();
        return new NoiseColumn(minY,states);
    }
}
