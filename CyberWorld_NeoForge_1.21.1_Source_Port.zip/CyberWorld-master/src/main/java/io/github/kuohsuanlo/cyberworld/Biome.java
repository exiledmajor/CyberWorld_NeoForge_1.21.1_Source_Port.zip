package io.github.kuohsuanlo.cyberworld;

/** Legacy biome labels used only by CyberWorld's old surface-material selection. */
public enum Biome {
    BADLANDS, BEACH, BIRCH_FOREST, DARK_FOREST, DEEP_OCEAN, DESERT, FLOWER_FOREST, FOREST, FROZEN_OCEAN, JUNGLE, MANGROVE_SWAMP, OCEAN, OLD_GROWTH_BIRCH_FOREST, OLD_GROWTH_PINE_TAIGA, OLD_GROWTH_SPRUCE_TAIGA, PLAINS, RIVER, SAVANNA, SNOWY_BEACH, SNOWY_TAIGA, STONY_SHORE, SUNFLOWER_PLAINS, SWAMP, TAIGA, WINDSWEPT_FOREST, WINDSWEPT_HILLS;
    public static Biome fromModernName(String value) {
        String name = value.toUpperCase(java.util.Locale.ROOT);
        if (name.equals("OLD_GROWTH_BIRCH_FOREST")) return OLD_GROWTH_BIRCH_FOREST;
        if (name.equals("OLD_GROWTH_PINE_TAIGA")) return OLD_GROWTH_PINE_TAIGA;
        if (name.equals("OLD_GROWTH_SPRUCE_TAIGA")) return OLD_GROWTH_SPRUCE_TAIGA;
        if (name.equals("WINDSWEPT_HILLS")) return WINDSWEPT_HILLS;
        try { return valueOf(name); } catch (IllegalArgumentException ignored) { return FOREST; }
    }
}
