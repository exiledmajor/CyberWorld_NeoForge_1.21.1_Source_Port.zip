package io.github.kuohsuanlo.cyberworld;

import net.neoforged.fml.loading.FMLPaths;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.logging.Logger;

/** Static settings and bundled schematic extraction for the NeoForge build. */
public final class CyberWorld {
    private static volatile CyberWorld instance;
    public static String WINDOWS_PATH;
    private final Logger log = Logger.getLogger("CyberWorld");
    private final Path dataFolder;

    public int BIOME_TYPES=3;
    public int BIOME_NUMBER_WITH_BUILDING=5;
    public int BIOME_OCTAVE=5;
    public int GROUND_LEVEL=50;
    public double SIGN_WALL_BLOCK_RATIO=0.4;
    public double SIGN_WALL_MINIMAL_WIDTH=12;
    public double SIGN_WALL_COVERAGE_RATIO_MIN=0.2;
    public double SIGN_WALL_COVERAGE_RATIO_MAX=0.8;
    public int GROUND_SIGN_EXTRA_HEIGHT_MAX=20;
    public int GROUND_SIGN_CONTENT_HEIGHT_MAX=4;
    public int GROUND_SIGN_HEIGHT_BASE=10;
    public int GROUND_SIGN_BASE_HZ_SHIFT_MAX=4;
    public double HEIGHT_RAND_ODDS=0.5;
    public double HEIGHT_RAND_RATIO=1.5;
    public int MAP_W=1000, MAP_H=1000, TERRAIN_OCTAVE=8, TERRAIN_HEIGHT=100, SEA_LEVEL=45;
    public int[] all_building_level, underground_building_level, LAYER_HEIGHT;
    public int L1_HEIGHT=20, L2_HEIGHT=40, L3_HEIGHT=80;
    public int sz_deco=1, sz_s=2, sz_m=4, sz_l=15, sz_block=20;

    private CyberWorld() {
        dataFolder = FMLPaths.CONFIGDIR.get().resolve("cyberworld");
        WINDOWS_PATH = dataFolder.resolve("schematics").toString() + File.separator;
        all_building_level = new int[]{GROUND_LEVEL+3,GROUND_LEVEL+3,GROUND_LEVEL+3};
        underground_building_level = new int[]{3,3,3};
        LAYER_HEIGHT = new int[]{GROUND_LEVEL+L1_HEIGHT,GROUND_LEVEL+L2_HEIGHT,GROUND_LEVEL+L3_HEIGHT};
        extractBundledSchematics();
    }
    public static CyberWorld getInstance() {
        CyberWorld current=instance;
        if (current==null) synchronized (CyberWorld.class) { if (instance==null) instance=new CyberWorld(); current=instance; }
        return current;
    }
    public void reportMessage(String message) { log.info("[CyberWorld] " + message); }
    private void extractBundledSchematics() {
        Path marker=dataFolder.resolve("schematics/.cyberworld-defaults-installed");
        if (Files.exists(marker)) return;
        try {
            Files.createDirectories(dataFolder);
            try (InputStream resource=getClass().getResourceAsStream("/schematics/schematics.zip")) {
                if (resource==null) { log.warning("Bundled schematic archive missing; add old .schematic files under " + WINDOWS_PATH); return; }
                try (ZipInputStream zip=new ZipInputStream(resource)) {
                    ZipEntry entry;
                    Path base=dataFolder.toRealPath();
                    while ((entry=zip.getNextEntry())!=null) {
                        Path output=dataFolder.resolve(entry.getName().replace('\\','/')).normalize();
                        if (!output.startsWith(dataFolder.normalize())) throw new java.io.IOException("Unsafe schematic path: " + entry.getName());
                        if (entry.isDirectory()) Files.createDirectories(output);
                        else {
                            Files.createDirectories(output.getParent());
                            if (!Files.exists(output)) try (OutputStream out=new BufferedOutputStream(Files.newOutputStream(output))) { zip.transferTo(out); }
                        }
                        zip.closeEntry();
                    }
                }
            }
            Files.createDirectories(marker.getParent()); Files.createFile(marker);
            log.info("Installed CyberWorld's bundled schematics to " + dataFolder);
        } catch (Exception ex) { log.warning("Could not install CyberWorld schematics: " + ex.getMessage()); }
    }
}
