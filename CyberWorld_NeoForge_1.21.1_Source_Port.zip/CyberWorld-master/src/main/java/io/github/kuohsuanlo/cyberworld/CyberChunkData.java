package io.github.kuohsuanlo.cyberworld;

import net.minecraft.world.level.block.state.BlockState;

/** Per-chunk scratch buffer. Null entries mean air; the original generator only writes Y=0..255. */
public final class CyberChunkData {
    public static final int MIN_Y = 0;
    public static final int MAX_Y = 256;
    private static final int AREA = 16 * 16;
    private final BlockState[] states = new BlockState[AREA * MAX_Y];
    private static int index(int x, int y, int z) { return (y << 8) | (z << 4) | x; }
    public int getMinHeight() { return MIN_Y; }
    public int getMaxHeight() { return MAX_Y; }
    public BlockState getStoredBlockState(int x, int y, int z) {
        if (x < 0 || x > 15 || z < 0 || z > 15 || y < MIN_Y || y >= MAX_Y) return null;
        return states[index(x, y, z)];
    }
    public BlockState getBlockState(int x, int y, int z) {
        if (x < 0 || x > 15 || z < 0 || z > 15 || y < MIN_Y || y >= MAX_Y) return net.minecraft.world.level.block.Blocks.AIR.defaultBlockState();
        BlockState state = states[index(x, y, z)];
        return state == null ? net.minecraft.world.level.block.Blocks.AIR.defaultBlockState() : state;
    }
    public Material getType(int x, int y, int z) {
        return Material.fromBlock(getBlockState(x, y, z).getBlock());
    }
    public void setBlock(int x, int y, int z, Material material) { setBlock(x, y, z, material.defaultBlockState()); }
    public void setBlock(int x, int y, int z, BlockState state) {
        if (x < 0 || x > 15 || z < 0 || z > 15 || y < MIN_Y || y >= MAX_Y) return;
        states[index(x, y, z)] = state;
    }
    public void setRegion(int x1, int y1, int z1, int x2, int y2, int z2, Material material) {
        int minY = Math.max(y1, MIN_Y), maxY = Math.min(y2, MAX_Y);
        if (x1 >= x2 || z1 >= z2 || minY >= maxY) return;
        for (int x = Math.max(0,x1); x < Math.min(16,x2); x++)
            for (int y = minY; y < maxY; y++)
                for (int z = Math.max(0,z1); z < Math.min(16,z2); z++) setBlock(x,y,z,material);
    }
    public BlockState[] copyStates() { return states.clone(); }
}
