package io.github.kuohsuanlo.cyberworld;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** Small compatibility wrapper for the finite set of block names used by CyberWorld's old Bukkit code. */
public final class Material {
    private static final Map<String, Material> BY_NAME = new HashMap<>();
    private static final Map<Block, Material> BY_BLOCK = new HashMap<>();
    public final Block block;
    private final String name;

    private Material(String name) {
        this.name = name.toUpperCase(Locale.ROOT);
        ResourceLocation id = ResourceLocation.fromNamespaceAndPath("minecraft", name.toLowerCase(Locale.ROOT));
        Block found = BuiltInRegistries.BLOCK.get(id);
        if (found == null || found == Blocks.AIR && !"AIR".equals(this.name)) found = Blocks.STONE;
        this.block = found;
        BY_BLOCK.putIfAbsent(found, this);
    }
    public static Material byName(String name) {
        String normalized = name.toUpperCase(Locale.ROOT);
        return BY_NAME.computeIfAbsent(normalized, n -> new Material(n));
    }
    public static Material fromBlock(Block block) {
        Material known = BY_BLOCK.get(block);
        if (known != null) return known;
        ResourceLocation key = BuiltInRegistries.BLOCK.getKey(block);
        return byName(key == null ? "STONE" : key.getPath());
    }
    public String name() { return name; }
    public BlockState defaultBlockState() { return block.defaultBlockState(); }
    public boolean isBlock() { return true; }
    public static Material valueOf(String name) { return byName(name); }
    public static Material matchMaterial(String name) { try { return byName(name); } catch (RuntimeException ex) { return STONE; } }

    public static final Material AIR = byName("air");
    public static final Material BEDROCK = byName("bedrock");
    public static final Material BRICKS = byName("bricks");
    public static final Material CLAY = byName("clay");
    public static final Material COAL_ORE = byName("coal_ore");
    public static final Material COBBLESTONE = byName("cobblestone");
    public static final Material COBBLESTONE_STAIRS = byName("cobblestone_stairs");
    public static final Material COBBLESTONE_WALL = byName("cobblestone_wall");
    public static final Material DIRT = byName("dirt");
    public static final Material GLASS = byName("glass");
    public static final Material GLOWSTONE = byName("glowstone");
    public static final Material GRASS_BLOCK = byName("grass_block");
    public static final Material GRAVEL = byName("gravel");
    public static final Material IRON_BARS = byName("iron_bars");
    public static final Material IRON_ORE = byName("iron_ore");
    public static final Material IRON_TRAPDOOR = byName("iron_trapdoor");
    public static final Material MOSSY_COBBLESTONE = byName("mossy_cobblestone");
    public static final Material OAK_FENCE = byName("oak_fence");
    public static final Material OBSIDIAN = byName("obsidian");
    public static final Material QUARTZ_BLOCK = byName("quartz_block");
    public static final Material RED_SANDSTONE = byName("red_sandstone");
    public static final Material SAND = byName("sand");
    public static final Material SNOW_BLOCK = byName("snow_block");
    public static final Material STONE = byName("stone");
    public static final Material STONE_SLAB = byName("stone_slab");
    public static final Material WATER = byName("water");
}
