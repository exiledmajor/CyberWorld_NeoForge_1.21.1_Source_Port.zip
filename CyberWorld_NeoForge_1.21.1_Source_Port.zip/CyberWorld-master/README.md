# CyberWorld for NeoForge 1.21.1

CyberWorld's original procedural cyberpunk city generator ported from Bukkit/Paper to a native NeoForge chunk generator. It retains the original city layout, road, building, sewer, factory, highway, signage, and schematic algorithms.

## Build

Requires JDK 21, Gradle 8.10+, and internet access to resolve the NeoForge ModDev plugin and Minecraft dependencies.

```bash
gradle clean build
```

The output JAR is in `build/libs/`. This archive includes source and assets; it is not a precompiled JAR.

## Install/use

Install the built JAR in a Minecraft 1.21.1 NeoForge client or server `mods/` folder. Create a fresh world and select **CyberWorld** in the world-type selector. The included `minecraft:normal` world-preset tag registers it for that selector. Back up existing saves before testing, and use a new world for the initial test.

See [PORT-STATUS.md](PORT-STATUS.md) for implementation notes and known limits.
