@echo off
REM Run from a terminal with Gradle 8.10+ installed and JDK 21 available.
gradle clean build
pause
